# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table item (
  id                            bigint not null,
  name                          varchar(255),
  description                   varchar(255),
  constraint pk_item primary key (id)
);
create sequence item_seq;

create table user (
  email                         varchar(255) not null,
  f_name                        varchar(255),
  l_name                        varchar(255),
  password                      varchar(255),
  role                          varchar(255),
  constraint pk_user primary key (email)
);


# --- !Downs

drop table if exists item;
drop sequence if exists item_seq;

drop table if exists user;

