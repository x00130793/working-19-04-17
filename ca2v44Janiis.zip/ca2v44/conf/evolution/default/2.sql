# --- Sample dataset

# --- !Ups
INSERT into item values (1, 'Dublin Zoo', 'Great Park');




insert into user values ('admin@products.com', 'Alice', 'Poo', 'password' );

insert into user values ( 'manager@products.com', 'Bob', 'Boooooob', 'password');

insert into user values ( 'customer@products.com', 'Charlie', 'Chuj', 'password' );
