package controllers;

import play.api.Environment;
import play.mvc.*;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import views.html.*;

import models.*;
import models.users.User;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */


    private FormFactory formFactory;

    @Inject
    public HomeController(FormFactory f) {
        this.formFactory = f;
    }

    public Result index() {
        return ok(index.render(getUserFromSession()));
    }

    public Result discDub() {
        return ok(discDub.render(getUserFromSession()));
    }

    public Result toDo() {
        return ok(toDo.render(getUserFromSession()));
    }

    public Result food() {
        return ok(food.render(getUserFromSession()));
    }

    public Result party() {
        return ok(party.render(getUserFromSession()));
    }

    public Result toDo1(){
	return ok(toDo1.render(getUserFromSession()));
    }

    public Result toDo2(){
	return ok(toDo2.render(getUserFromSession()));
    }


    public Result signup() {
        return ok(signup.render(getUserFromSession()));
    }

    public Result items() {
        List<Item> itemsList = Item.findAll();
        return ok(items.render(itemsList, getUserFromSession()));
    }

    @Security.Authenticated(Secured.class)
    public Result fotm() {
        Form<Item> addItemForm = formFactory.form(Item.class);
	

        return ok(fotm.render(addItemForm, getUserFromSession()));
    }

    public Result addItemSubmit() {
        Form<Item> newItemForm = formFactory.form(Item.class).bindFromRequest();

        if (newItemForm.hasErrors()) {
            return badRequest(fotm.render(newItemForm, getUserFromSession()));
        }

        Item i = newItemForm.get();

        if (i.getId() == null) {

            i.save();
        } else if (i.getId() != null) {
            i.update();
        }

        flash("success", "Product " + i.getName() + " has been created");

        return redirect(controllers.routes.HomeController.items());
    }
    @Security.Authenticated(Secured.class)
    @Transactional
    public Result deleteItem(Long id) {
        Item.find.ref(id).delete();

        flash("success", "Item has been deleted");

        return redirect(routes.HomeController.items());
    }

    @Security.Authenticated(Secured.class)
    @Transactional
    public Result updateItem(Long id){

        Item i = Item.find.byId(id);
        Form<Item> itemForm = formFactory.form(Item.class).fill(i);

        return ok(fotm.render(itemForm, getUserFromSession()));


    }
    //Returns the logged in user
    private User getUserFromSession() {
        return User.getUserById(session().get("email"));
    }



}



