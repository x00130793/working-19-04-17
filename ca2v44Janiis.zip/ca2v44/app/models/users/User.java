package models.users;

import java.util.*;
import javax.persistence.*;

import com.avaje.ebean.Model;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class User extends Model{

    @Id
    private String email;

    @Constraints.Required
    private String fName;

    @Constraints.Required
    private String lName;

    @Constraints.Required
    private String password;

    @Constraints.Required
    private String role;


    public User(){

    }

    public static Finder<String, User> find = new Finder<String, User>(User.class);

    public static List<User> findAll() {
        return User.findAll();
    }

    public static User authenticate(String email, String password) {
        // If found return user object with matching email and password
        return find.where().eq("email", email).eq("password", password).findUnique();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public static Finder<String, User> getFind() {
        return find;
    }

    public static void setFind(Finder<String, User> find) {
        User.find = find;
    }

    // Check if a user is logged in
    public static User getUserById(String id){
        if(id == null)
            return null;
        else return find.byId(id);
    }
}
