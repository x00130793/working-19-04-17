package models;

import java.util.*;
import javax.persistence.*;

import play.data.format.*;
import play.data.validation.*;

import com.avaje.ebean.*;

@Entity
public class Item extends Model{

    @Id
    private Long id;

    @Constraints.Required
    private String name;

    @Constraints.Required
    private String description;




    public Item() {

    }

    public Item(Long idIn, String nameIn, String descriptionIn) {
        id = idIn;
        name = nameIn;
        description = descriptionIn;
    }

    public Long getId(){
        return id;
    }

    public void setId(Long idIn) {
        id = idIn;
    }

    public String getName() {
        return name;
    }

    public void setName(String nameIn) {
        name = nameIn;
    }

    public String getDescription() {
        return description;
    }
    
    public void setDescription(String descriptionIn) {
        description = descriptionIn;
    }

   public static Finder<Long, Item> find = new Finder<Long, Item>(Item.class);

    public static List<Item>findAll() {
        return Item.find.all();
    }




}
