# --- Sample dataset

# --- !Ups
INSERT into item values (1, 'Dublin Zoo', 'Great Park');
